import unreal_engine as ue
from unreal_engine import FVector

import threading
import time
import grpc

import soscon.proto.soscon_pb2_grpc as rpc
import soscon.proto.soscon_pb2 as rpc_data

from concurrent import futures


class Env(rpc.SOSCONServicer):

    """
    UE4 Event
    """
    def begin_play(self):
        ue.log("Begin Play")

        self._rpc_mutex = threading.RLock()
        self._is_connected = False
        self._initialize = True

        self._owner = self.uobject.get_owner()
        self._owner.set_obj_flags(ue.RF_PUBLIC | ue.RF_STANDALONE)

        self._received_control = False
        self._robot_linear = 0.0
        self._robot_angular = 0.0

    def tick(self, delta_time):
        if not self._is_connected:
            ue.log_error("RPC is not connecting")
            return

        with self._rpc_mutex:
            if self._initialize:
                self._initialize = False
                self._owner.Initialize()

        if self._received_control:
            self.execute_control(self._robot_linear, self._robot_angular)
            self._received_control = False

    def end_play(self, reason):
        ue.log("End Play")
        with self._rpc_mutex:
            if self._is_connected:
                self._server.stop(grace=0)

    """
    GRPC Server
    """
    def connect_rpc(self, port):
        port = 30000
        try:
            self._server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
            rpc.add_SOSCONServicer_to_server(servicer=self, server=self._server)
            self._server.add_insecure_port("[::]:%d" % port)
            self._server.start()
            self._is_connected = True

        except Exception as e:
            ue.log_warning("[ConnectRPC] Error: " + str(e))
            self._is_connected = False


    """
    Proto Servicer Override
        - rpc move (Control) returns (Empty)
        - rpc observation (Empty) returns (Observation)
        - rpc constants (Empty) returns (Constant)
    """
    def move(self, request, context):
        with self._rpc_mutex:
            if type(request) is not rpc_data.Control:
                ue.log_error("Action type Error")
                raise TypeError

            self._received_control = True
            self._robot_linear = request.linear
            self._robot_angular = request.angular
            return (rpc_data.Empty())

    def observation(self, request, context):
        with self._rpc_mutex:
            if type(request) is not rpc_data.Empty:
                ue.log_error("Observation Type Error")
                raise TypeError

            observation = rpc_data.Observation(
                image = Observation.image,
                boundingbox = Observation.boundingbox,
                ir = Observation.ir,
                lidar = Observation.lidar,
                left_encoder = Observation.left_encoder,
                right_encoder = Observation.right_encoder,
                delta_x = Observation.delta_x,
                delta_y = Observation.delta_y,
                compass = Observation.compass,
                elapsed_time = Observation.elapsed_time,
                robot_location = Observation.robot_location,
                robot_rotation = Observation.robot_rotation,
                coverage_rate = Observation.coverage_rate,
                )

            return observation

    def constants(self, request, context):
        with self._rpc_mutex:
            if type(request) is not rpc_data.Empty:
                ue.log_error("Constants Type Error")
                raise TypeError

            constant = rpc_data.Constant(
                wheel_radius = self._owner.get_property("WheelRadius"),
                wheel_seperation = self._owner.get_property("WheelSeperation"),
                max_linear_velocity = self._owner.get_property("MaxLinearVelocity"),
                max_angular_velocity = self._owner.get_property("MaxAngularVelocity"),
                robot_size = self._owner.get_property("RobotSize"),
                encoder_resolution = self._owner.get_property("EncoderResolution"),
            )

            return constant


    """
    Communicate with UE4
    """
    def execute_control(self, linear, angular):
        while True:
            try:
                self._owner.Move(linear, angular)
                return
            except Exception as e:
                ue.log_error("Execute Action Error : " + str(e))
                time.sleep(0.01)
            raise TimeoutError

    def extract_observation(self):
        while True:
            try:
                with self._rpc_mutex:
                    Observation.image = self._owner.get_property("Image")
                    Observation.ir = self._owner.get_property("IR")
                    Observation.lidar = self._owner.get_property("LiDAR")
                    Observation.boundingbox = Observation.convert_bounding_box(
                                                self._owner.get_property("BoundingBoxList"))
                    Observation.delta_x = self._owner.get_property("DeltaX")
                    Observation.delta_y = self._owner.get_property("DeltaY")
                    Observation.left_encoder = self._owner.get_property("LeftEncoderCounter")
                    Observation.right_encoder = self._owner.get_property("RightEncoderCounter")
                    Observation.compass = self._owner.get_property("Compass")
                    Observation.elapsed_time = self._owner.get_property("ElapsedSecs")
                    Observation.robot_location = self._owner.get_property("RobotLocation")
                    Observation.robot_rotation = self._owner.get_property("RobotRotator")
                    Observation.coverage_rate = self._owner.get_property("CoverageRate")
                    return
            except Exception as e:
                ue.log_error("Get Observation Error : " + str(e))
                time.sleep(0.01)
            raise TimeoutError

    def debug_point(self, request, context):
        with self._rpc_mutex:
            if type(request) is not rpc_data.DebugPoint:
                ue.log_error("Debug Point Type Error")
                raise TypeError
        
            self._owner.DebugPoint(FVector(request.point[0], request.point[1], request.point[2]),
                                    request.duration)
            return (rpc_data.Empty())
        
    def debug_line(self, request, context):
        with self._rpc_mutex:
            if type(request) is not rpc_data.DebugLine:
                ue.log_error("Debug Line Type Error")
                raise TypeError

            self._owner.DebugLine(FVector(request.start_point[0], request.start_point[1], request.start_point[2]),
                                FVector(request.end_point[0], request.end_point[1], request.end_point[2]),
                                request.duration)
            
            return (rpc_data.Empty())
            

class Observation():
    image: list = []
    boundingbox: list = []
    ir: list = []
    lidar: list = []
    left_encoder: int = 0
    right_encoder: int = 0
    delta_x: float = 0.0
    delta_y: float = 0.0
    compass: float = 0.0
    elapsed_time: float = 0.0
    robot_location: list = [0.0, 0.0, 0.0]
    robot_rotation: list = [0.0, 0.0, 0.0]
    coverage_rate: float = 0.0

    @staticmethod
    def convert_bounding_box(ue4_bbox_list):
        VECTOR_SIZE = 3
        CLASS_SIZE = 1

        i = 0
        n = int(len(ue4_bbox_list) / 10)

        bbox_list = []

        try:
            for _ in range(i, n):
                _origin = ue4_bbox_list[i:i + VECTOR_SIZE]
                i += VECTOR_SIZE

                _extent = ue4_bbox_list[i:i + VECTOR_SIZE]
                i += VECTOR_SIZE

                _rotation = ue4_bbox_list[i:i + VECTOR_SIZE]
                i += VECTOR_SIZE

                _class_id = int(ue4_bbox_list[i])
                i += CLASS_SIZE

                bbox = rpc_data.Observation.BoundingBox(
                    origin=_origin,
                    extent=_extent,
                    rotation=_rotation,
                    class_id=_class_id
                )
                bbox_list.append(bbox)
        except Exception as e:
            ue.log_error("Converting BBox Error : " + str(e))
            time.sleep(0.01)

        return bbox_list
